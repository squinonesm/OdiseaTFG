PixelFX_vol 1

frame: 30fps
framesize: 64*64 pixel
Total Sprite Sheet number:33
Transparency :Yes
Color Depth: 32 bit
Sprite Size: 1920*64 pixel

*All sprites are looping animation.

File 1 [anim]
Content: 33 anim 

File 2 [Controllers]
Content: 33 Animator Controller

File 3 [Pref]
Content: 33 pref(15 fire FX & 18 smoke FX)

File 4 [Sprite]
-Content File 1: [Fire]
  Subfile 1: [Idle]
  -5 png(1920*64 pixel)
  Subfile 2: [Side]
  -5 png(1920*64 pixel)
  Subfile 3: [UpDown]
  -5 png(1920*64 pixel)

-Content File 2: [Smoke]
  Subfile 1: [Smokel]
  -6 png(1920*64 pixel)
  Subfile 2: [Smokem]
  -6 png(1920*64 pixel)
  Subfile 3: [Smokes]
  -6 png(1920*64 pixel)


Remind: credit #AoiSani(asset publisher) when use it 

